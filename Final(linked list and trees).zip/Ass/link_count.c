#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;          
    struct node *link;
}*first;


void createList(int n);
int countNodes();
void display();


void main()
{
    int n, total;
    printf("Enter the total number of nodes: ");
    scanf("%d", &n);
    createList(n);

    printf("\ninfo in the list \n");
    display();

    total = countNodes();
  
}

void createList(int n)
{
    struct node *newNode, *save;
    int info, i;

    first = (struct node *)malloc(sizeof(struct node));
    if(first == NULL)
    {
        printf("Unable to allocate memory.");
    }
    else
    {
        printf("Enter the info of node 1: ");
        scanf("%d", &info);

        first->info = info; 
        first->link = NULL; 

        save = first;

        for(i=2; i<=n; i++)
        {
            newNode = (struct node *)malloc(sizeof(struct node));
            if(newNode == NULL)
            {
                printf("Unable to allocate memory.");
                break;
            }
            else
            {
                printf("Enter the info of node %d: ", i);
                scanf("%d", &info);

                newNode->info = info;
                newNode->link = NULL; 

                save->link = newNode; 
                save = save->link;
            }
        }

        printf("SINGLY LINKED LIST CREATED SUCCESSFULLY\n");
    }
}

int countNodes()
{
    int count = 0;
    struct node *save;

    save = first;

    while(save != NULL)
    {
        count++;
        save = save->link;
    }

    return count;
}

void display()
{
    struct node *save;

    if(first == NULL)
    {
        printf("List is empty.");
    }
    else
    {
        save = first;
        while(save != NULL)
        {
            printf("info = %d\n", save->info); 
            save = save->link;                 
        }
    }
}
