#include <stdio.h>
#include <stdlib.h>

struct node {
    int info;          
    struct node *link; 
}*first;


void createList(int n);
void insertNodeAtBeginning(int info);
void insertNodeAtMiddle(int info, int position);
void insertNodeAtEnd(int info);
void display();

void main()
{
    int n, info;
    printf("Enter the total number of nodes: ");
    scanf("%d", &n);
    createList(n);

    printf("\ninfo in the list \n");
    display();

    printf("\nEnter info to insert at beginning of the list: ");
    scanf("%d", &info);
    insertNodeAtBeginning(info);

    printf("\ninfo in the list \n");
    display();

}

void createList(int n)
{
    struct node *newNode, *save;
    int info, i;

    first = (struct node *)malloc(sizeof(struct node));
    if(first == NULL)
    {
        printf("Overflow");
    }
    else
    {
        printf("Enter the info of node 1: ");
        scanf("%d", &info);

        first->info = info;
        first->link = NULL; 

        save = first;

        for(i=2; i<=n; i++)
        {
            newNode = (struct node *)malloc(sizeof(struct node));
            if(newNode == NULL)
            {
                printf("Overflow");
                break;
            }
            else
            {
                printf("Enter the info of node %d: ", i);
                scanf("%d", &info);

                newNode->info = info; 
                newNode->link = NULL; 
                save->link = newNode; 
                save = save->link; 
            }
        }
    }
}

void insertNodeAtBeginning(int info)
{
    struct node *newNode;

    newNode = (struct node*)malloc(sizeof(struct node));

    if(newNode == NULL)
    {
        printf("Overflow");
    }
    else
    {
        newNode->info = info; 
        newNode->link = first;

        first = newNode;  

    }
}

void insertNodeAtMiddle(int info, int position)
{
    int i;
    struct node *newNode, *save;
    newNode = (struct node*)malloc(sizeof(struct node));
    if(newNode == NULL)
    {
        printf("Overflow");
    }
    else
    {
        newNode->info = info; 
        newNode->link = NULL;
        save = first;
        for(i=2; i<=position-1; i++)
        {
            save = save->link;

            if(save == NULL)
                break;
        }
        if(save != NULL)
        {
            newNode->link = save->link; 
            save->link = newNode;

        }
        else
        {
            printf("UNABLE TO INSERT info AT THE GIVEN POSITION\n");
        }
    }
}


void insertNodeAtEnd(int info)
{
    struct node *newNode, *save;

    newNode = (struct node*)malloc(sizeof(struct node));

    if(newNode == NULL)
    {
        printf("Overflow");
    }
    else
    {
        newNode->info = info; 
        newNode->link = NULL; 

        save = first;

        while(save != NULL && save->link != NULL)
            save = save->link;

        save->link = newNode; 
    }
}


void display()
{
    struct node *save;

    if(first == NULL)
    {
        printf("List is empty.");
    }
    else
    {
        save = first;
        while(save != NULL)
        {
            printf("info = %d\n", save->info); 
            save = save->link;                 
        }
    }
}
