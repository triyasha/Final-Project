#include <stdio.h>
#include <stdlib.h>

struct node{
char data;
struct node *l;
struct node *r;
};

void pre_order(struct node *);
void in_order(struct node *);
void post_order(struct node *);

void main()
{
    struct node *t,*a, *b, *c, *d, *e, *f, *g;
    t=a;
    a=(struct node *)malloc(sizeof(struct node));
    b=(struct node *)malloc(sizeof(struct node));
    c=(struct node *)malloc(sizeof(struct node));
    d=(struct node *)malloc(sizeof(struct node));
    e=(struct node *)malloc(sizeof(struct node));
    f=(struct node *)malloc(sizeof(struct node));
    g=(struct node *)malloc(sizeof(struct node));
  
    t=a;
    a->data='A';
    a->l=b;
    a->r=d;

    b->data='B';
    b->l=c;
    b->r=NULL;

    c->data='C';
    c->l=NULL;
    c->r=NULL;

    d->data='D';
    d->l=e;
    d->r=g;

    e->data='E';
    e->l=NULL;
    e->r=f;
  
    f->data='F';
    f->l=NULL;
    f->r=NULL;

    g->data='G';
    g->l=NULL;
    g->r=NULL;

printf("PREORDER is \n");
pre_order(t);

printf("\nINORDER is \n");
in_order(t);

printf("\nPOSTORDER is \n");
post_order(t);
}

void pre_order(struct node *t)
{
if(t == NULL)
printf("Empty Tree");
else
{
    printf("%c ", t->data);
    if(t->l != NULL)
    {
        pre_order(t->l);
    }
    if(t->r != NULL)
    {
        pre_order(t->r);
    }
}
}


void in_order(struct node *t)
{
if(t == NULL)
printf("Empty Tree");
else
{
    if(t->l != NULL)
    {
        in_order(t->l);
    }
printf("%c ", t->data);
    if(t->r != NULL)
    {
        in_order(t->r);
    }

}
}


void post_order(struct node *t)
{
if(t == NULL)
printf("Empty Tree");
else
{
    if(t->l != NULL)
    {
        post_order(t->l);
    }
    if(t->r != NULL)
    {
        post_order(t->r);
    }
printf("%c ", t->data);
}
}
