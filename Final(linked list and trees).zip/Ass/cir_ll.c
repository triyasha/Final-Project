#include <stdio.h>
#include <stdlib.h>

struct node {
    int field;
    struct node * next;
}*head;

void createList(int n);
void displayList();
void insertAtBeginning(int field);
void insertAtN(int field, int position);

void main()
{
    int n, field, choice=1;
    head = NULL;
    while(choice != 0)
    {
        printf("1. Create List\n");
        printf("2. Display list\n");
        printf("3. Insert at beginning\n");
        printf("4. Insert at any position\n");
        printf("5. Exit\n");
        printf("Enter your choice : ");

        scanf("%d", &choice);

        switch(choice)
        {
            case 1:
                printf("Enter the total number of nodes in list: ");
                scanf("%d", &n);
                createList(n);
                break;
            case 2:
                displayList();
                break;
            case 3:
                printf("Enter field to be inserted at beginning: ");
                scanf("%d", &field);
                insertAtBeginning(field);
                break;
            case 4:
                printf("Enter node position: ");
                scanf("%d", &n);
                printf("Enter field you want to insert at %d position: ", n);
                scanf("%d", &field);
                insertAtN(field, n);
                break;
            case 5:
                break;
            default:
                printf("Invalid");
        }
    }

}

void createList(int n)
{
    int i, field;
    struct node *prevNode, *newNode;

    if(n >= 1)
    {
        head = (struct node *)malloc(sizeof(struct node));

        printf("Enter field of 1 node: ");
        scanf("%d", &field);

        head->field = field;
        head->next = NULL;

        prevNode = head;

        for(i=2; i<=n; i++)
        {
            newNode = (struct node *)malloc(sizeof(struct node));

            printf("Enter field of %d node: ", i);
            scanf("%d", &field);

            newNode->field = field;
            newNode->next = NULL;

            prevNode->next = newNode;
         
            prevNode = newNode;
        }

        prevNode->next = head;
    }
}

void displayList()
{
    struct node *current;
    int n = 1;

    if(head == NULL)
    {
        printf("List is empty.\n");
    }
    else
    {
        current = head;
        printf("field IN THE LIST:\n");

        do {
            printf("field %d = %d\n", n, current->field);

            current = current->next;
            n++;
        }while(current != head);
    }
}

void insertAtBeginning(int field)
{
    struct node *newNode, *current;

    if(head == NULL)
    {
        printf("List is empty.\n");
    }
    else
    {
        newNode = (struct node *)malloc(sizeof(struct node));
        newNode->field = field;
        newNode->next = head;

        current = head;
        while(current->next != head)
        {
            current = current->next;
        }
        current->next = newNode;

        head = newNode;
    }
}

void insertAtN(int field, int position)
{
    struct node *newNode, *current;
    int i;

    if(head == NULL)
    {
        printf("List is empty.\n");
    }
    else if(position == 1)
    {
        insertAtBeginning(field);
    }
    else
    {
        newNode = (struct node *)malloc(sizeof(struct node));
        newNode->field = field;

        current = head;
        for(i=2; i<=position-1; i++)
        {
            current = current->next;
        }

        newNode->next = current->next;
        current->next = newNode;

    }
}
