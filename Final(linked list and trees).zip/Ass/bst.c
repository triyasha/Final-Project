#include <stdio.h>
#include <stdlib.h>

struct node {
  int data;
  struct node *l, *r;
};

void in_order(struct node *t);
struct node *newNode(int e);
struct node *insert(struct node *node, int data);
struct node *min_value(struct node *node);
struct node* del_node(struct node* t, int data);

void main() {
  struct node *t = NULL;
  t = insert(t, 50);
  t = insert(t, 25);
  t = insert(t, 22);
  t = insert(t, 40);
  t = insert(t, 60);
  t = insert(t, 80);
  t = insert(t, 90);
  t = insert(t, 15);
  t = insert(t, 30);

  printf("Inorder traversal: ");
  in_order(t);

  printf("\nDelete 40\n");
  t = del_node(t, 40);
  printf("Inorder traversal of the modified tree \n");
  in_order(t);

  printf("\nDelete 30\n");
  t = del_node(t, 30);
  printf("Inorder traversal of the modified tree \n");
  in_order(t);

}

void in_order(struct node *t)
{
if(t == NULL)
printf("Empty Tree");
else
{
    if(t->l != NULL)
    {
        in_order(t->l);
    }
printf("%d ", t->data);
    if(t->r != NULL)
    {
        in_order(t->r);
    }

}
}

struct node *newNode(int e) {
  struct node *A = (struct node *)malloc(sizeof(struct node));
  A->data = e;
  A->l = A->r = NULL;
  return A;
}

struct node *insert(struct node *node, int data) {
 
if (node == NULL) 
return newNode(data);


if (data < node->data)
    node->l = insert(node->l, data);
else
    node->r = insert(node->r, data);

  return node;
}


struct node *min_value(struct node *node) {
  struct node *current = node;

  while (current && current->l != NULL)
    current = current->l;

  return current;
}

struct node* del_node(struct node* t, int data)
{
	if (t == NULL)
		return t;

	if (data < t->data)
		t->l = del_node(t->l, data);

	else if (data > t->data)
		t->r = del_node(t->r, data);

	else {
		if (t->l == NULL) {
			struct node* e = t->r;
			free(t);
			return e;
		}
		else if (t->r == NULL) {
			struct node* e = t->l;
			free(t);
			return e;
		}

		struct node* e = min_value(t->r);

		t->data = e->data;
		t->r = del_node(t->r, e->data);
	}
	return t;
}

