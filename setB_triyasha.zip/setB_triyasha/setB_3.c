#include <stdio.h>
#include <stdint.h>

void main()
{
    
    int number = 0;
    printf("Enter your number\n");
    if (scanf("%u", &number)==1)
        reverse(number);

}

void value(int number) {
    
    printf("%d=", number);
    
    for (int i = 0;i<32;++i) {
        printf("%u", (number>>i) & 1);
    }    
    
    printf("\n");
    
}

int reverse(int s) {

    int result=0;
    
    value(s);
    
    for (int i = 0;i<32;++i) {
        uint8_t i_bit_value = (s >> i) & 1;
        result |= i_bit_value << (31-i) ;
    }    
    
    value(result);
    
    return result;

}


